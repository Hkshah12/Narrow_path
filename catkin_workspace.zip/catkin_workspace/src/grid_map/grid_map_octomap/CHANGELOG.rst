^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package grid_map_octomap
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.7.0 (2022-03-17)
------------------

1.6.4 (2020-12-04)
------------------

1.6.2 (2019-10-14)
------------------

1.6.1 (2019-02-27)
------------------
* Updated author e-mail address.
* Contributors: Peter Fankhauser

1.6.0 (2017-11-24)
------------------

1.5.2 (2017-07-25)
------------------

1.5.1 (2017-07-25)
------------------

1.5.0 (2017-07-18)
------------------
* Added new package for octomap to grid map conversion.
* Contributors: Jeff Delmerico, Peter Fankhauser
