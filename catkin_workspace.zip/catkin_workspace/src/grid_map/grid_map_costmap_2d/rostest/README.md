
I can never remember how to run them...

* http://wiki.ros.org/rostest/Commandline

```
rostest --text mytest.test
```

