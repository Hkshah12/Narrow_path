^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package grid_map_costmap_2d
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.7.0 (2022-03-17)
------------------

1.6.4 (2020-12-04)
------------------

1.6.2 (2019-10-14)
------------------

1.6.1 (2019-02-27)
------------------
* Merge pull request `#202 <https://github.com/ANYbotics/grid_map/issues/202>`_ from ANYbotics/fix/tf_for_indigo_and_kinetic
  Fix/tf for indigo and kinetic
* [grid_map_costmap_2d] Fixed test on melodic.
* [grid_map_costmap_2d] Tests using tf instead of tf2 for indigo/kinetic.
* Refactoring.
* Initializing ROSCostmap with tf buffer.
* typos fixed.
* fixed typo in initializer list.
* renamed member variable of costmap according to styleguide.
* fixed backwards compatibility for costmap_2d.
* Updated host changes.
* Updated author e-mail address.
* Contributors: Marco Sütterlin, Peter Fankhauser, Péter Fankhauser, Remo Diethelm, Samuel Bachmann

1.6.0 (2017-11-24)
------------------

1.5.2 (2017-07-25)
------------------

1.5.1 (2017-07-25)
------------------

1.5.0 (2017-07-18)
------------------
* Move costmap_2d conversion into separate package.
* Contributors: Peter Fankhauser
