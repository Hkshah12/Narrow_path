^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package grid_map
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.7.0 (2022-03-17)
------------------

1.6.4 (2020-12-04)
------------------

1.6.2 (2019-10-14)
------------------

1.6.1 (2019-02-27)
------------------
* Updated author e-mail address.
* Contributors: Peter Fankhauser

1.6.0 (2017-11-24)
------------------

1.5.2 (2017-07-25)
------------------

1.5.1 (2017-07-25)
------------------

1.5.0 (2017-07-18)
------------------

1.4.2 (2017-01-24)
------------------

1.4.1 (2016-10-23)
------------------
* Added new grid_map_pcl package.
* Contributors: Peter Fankhauser, Dominic Jud

1.4.0 (2016-08-22)
------------------
* Added new package grid_map_rviz_plugin.
* Contributors: Peter Fankhauser

1.3.3 (2016-05-10)
------------------
* Release for ROS Kinetic.
* Contributors: Peter Fankhauser

1.3.2 (2016-05-10)
------------------

1.3.1 (2016-05-10)
------------------

1.3.0 (2016-04-26)
------------------
* Separated OpenCV to grid map conversions to grid_map_cv package. The new methods
  are more generalized, faster, and can be used without ROS message types.
* Contributors: Peter Fankhauser

1.2.0 (2016-03-03)
------------------
* Added new package grid_map as metapackage (`#34 <https://github.com/anybotics/grid_map/issues/34>`_).
