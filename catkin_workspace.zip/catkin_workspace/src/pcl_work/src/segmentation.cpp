#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/filters/conditional_removal.h>
#include <limits> // For numeric_limits
#include <std_msgs/Float32.h> // For publishing float values
#include <geometry_msgs/Point32.h> // For handling points
#include <pcl_work/dimensions.h>  // Include the custom message header
#include <limits> // For numeric_limits
#include <cmath> 

// Publisher for the filtered point cloud
ros::Publisher filtered_pub;
ros::Publisher dimensions_pub;

// Callback function to process the incoming point cloud
void cloudCallback(const sensor_msgs::PointCloud2ConstPtr& input_cloud_msg) {
    // Convert ROS PointCloud2 to PCL PointCloud
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>());
    pcl::fromROSMsg(*input_cloud_msg, *cloud);

    // Check if the cloud is empty
    if (cloud->empty()) {
        ROS_WARN("Input cloud is empty.");
        return;
    }

    // Step 1: Filter points based on X and Z axes using a Conditional Filter
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered(new pcl::PointCloud<pcl::PointXYZ>());
    pcl::ConditionAnd<pcl::PointXYZ>::Ptr range_cond(new pcl::ConditionAnd<pcl::PointXYZ>());
    
    // Define the range for the X-axis
    range_cond->addComparison(pcl::FieldComparison<pcl::PointXYZ>::ConstPtr(
        new pcl::FieldComparison<pcl::PointXYZ>("x", pcl::ComparisonOps::GT, -0.650)));
    range_cond->addComparison(pcl::FieldComparison<pcl::PointXYZ>::ConstPtr(
        new pcl::FieldComparison<pcl::PointXYZ>("x", pcl::ComparisonOps::LT, -0.250)));
    
    // Define the range for the Y-axis
    range_cond->addComparison(pcl::FieldComparison<pcl::PointXYZ>::ConstPtr(
        new pcl::FieldComparison<pcl::PointXYZ>("y", pcl::ComparisonOps::GT, -6.750)));
    range_cond->addComparison(pcl::FieldComparison<pcl::PointXYZ>::ConstPtr(
        new pcl::FieldComparison<pcl::PointXYZ>("y", pcl::ComparisonOps::LT, 6.500)));

    // Define the range for the Z-axis
    range_cond->addComparison(pcl::FieldComparison<pcl::PointXYZ>::ConstPtr(
        new pcl::FieldComparison<pcl::PointXYZ>("z", pcl::ComparisonOps::GT, -1.10)));
    range_cond->addComparison(pcl::FieldComparison<pcl::PointXYZ>::ConstPtr(
        new pcl::FieldComparison<pcl::PointXYZ>("z", pcl::ComparisonOps::LT, -0.50)));

    // Apply the conditional filter
    pcl::ConditionalRemoval<pcl::PointXYZ> cond_rem;
    cond_rem.setCondition(range_cond);
    cond_rem.setInputCloud(cloud);
    cond_rem.setKeepOrganized(false); // KeepOrganized = false for better performance
    cond_rem.filter(*cloud_filtered);

    // Check if the filtered cloud is empty
    if (cloud_filtered->empty()) {
        ROS_WARN("Filtered cloud is empty. No points in the defined ROI.");
        return;
    }

    // Step 2: Calculate the dimensions of the filtered point cloud
    float min_x = std::numeric_limits<float>::max();
    float max_x = std::numeric_limits<float>::lowest();
    float min_y = std::numeric_limits<float>::max();
    float max_y = std::numeric_limits<float>::lowest();
    float min_z = std::numeric_limits<float>::max();
    float max_z = std::numeric_limits<float>::lowest();

    // Iterate through the filtered point cloud to find extreme points
    for (const auto& point : cloud_filtered->points) {
        // Update min and max for X axis
        if (point.x < min_x) min_x = point.x;
        if (point.x > max_x) max_x = point.x;

        // Update min and max for y axis
        if (point.y < min_y) min_y = point.y;
        if (point.y > max_y) max_y = point.y;
        
        // Update min and max for Z axis
        if (point.z < min_z) min_z = point.z;
        if (point.z > max_z) max_z = point.z;
    }
    
    // Calculate Euclidean distances for length and height
    // float width = std::sqrt(std::pow(max_x - min_x, 2)); // Distance along X-axis
    // float length = std::sqrt(std::pow(max_y - min_y, 2)); // Distance along y-axis
    // float height = std::sqrt(std::pow(max_z - min_z, 2)); // Distance along Z-axis
    // Calculate dimensions using Euclidean distances
    float width = std::abs(max_x - min_x);  // Distance along X-axis
    float length = std::abs(max_y - min_y); // Distance along Y-axis
    float height = std::abs(max_z - min_z); // Distance along Z-axis

    // Adjust dimensions to three decimal places
    width = std::round(width * 1000.0f) / 1000.0f;
    length = std::round(length * 1000.0f) / 1000.0f;
    height = std::round(height * 1000.0f) / 1000.0f;

    // Output the dimensions
    ROS_INFO_STREAM("Filtered Region Dimensions:");
    ROS_INFO_STREAM("Min X: " << std::fixed << std::setprecision(3) << min_x 
                  << ", Max X: " << max_x);
    ROS_INFO_STREAM("Min Y: " << std::fixed << std::setprecision(3) << min_y 
                  << ", Max Y: " << max_y);
    ROS_INFO_STREAM("Min Z: " << std::fixed << std::setprecision(3) << min_z 
                  << ", Max Z: " << max_z);
    ROS_INFO_STREAM("Width (X-axis): " << width <<" meters");
    ROS_INFO_STREAM("Length (Y-axis): "<< length <<" meters");
    ROS_INFO_STREAM("Height (Z-axis): "<< height <<" meters");

    // Step 3: Publish the filtered point cloud
    sensor_msgs::PointCloud2 filtered_msg;
    pcl::toROSMsg(*cloud_filtered, filtered_msg);
    filtered_msg.header = input_cloud_msg->header;
    filtered_pub.publish(filtered_msg);

    // Step 4: Publish the dimensions (width and height) as a single custom message
    pcl_work::dimensions dimensions_msg;
    dimensions_msg.width = width;  // Assign width to the message
    dimensions_msg.height = height;  // Assign height to the message
    dimensions_msg.length = length; //Assign length to the message
    dimensions_pub.publish(dimensions_msg);  // Publish the message

    ROS_INFO("Filtered cloud size: %ld", cloud_filtered->points.size());
}

int main(int argc, char** argv) {
    // Initialize ROS node
    ros::init(argc, argv, "pcl_roi_filtering");
    ros::NodeHandle nh;

    // Subscriber for the input point cloud
    // ros::Subscriber sub = nh.subscribe("/elevation_map_fused_visualization/elevation_cloud", 1, cloudCallback);
    ros::Subscriber sub = nh.subscribe("/rtabmap/cloud_map", 1, cloudCallback);

    // Publisher for the filtered point cloud
    filtered_pub = nh.advertise<sensor_msgs::PointCloud2>("filtered_cloud", 1);

    // Publisher for the custom dimensions message (length and height)
    dimensions_pub = nh.advertise<pcl_work::dimensions>("dimensions_work", 1);  // Topic for dimensions

    // Spin to process incoming messages
    ros::spin();

    return 0;
}
