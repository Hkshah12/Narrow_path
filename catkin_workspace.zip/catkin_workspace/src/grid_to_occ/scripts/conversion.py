#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import PointCloud2, PointField
from grid_map_msgs.msg import GridMap
from std_msgs.msg import Header
import struct

def gridmap_to_pointcloud2(grid_map_msg):
    """
    Converts a GridMap message to a PointCloud2 message.

    Args:
        grid_map_msg (GridMap): Input GridMap message.

    Returns:
        PointCloud2: Converted PointCloud2 message.
    """
    header = Header()
    header.stamp = rospy.Time.now()
    header.frame_id = grid_map_msg.info.header.frame_id  # Maintain the original frame

    fields = [
        PointField('x', 0, PointField.FLOAT32, 1),
        PointField('y', 4, PointField.FLOAT32, 1),
        PointField('z', 8, PointField.FLOAT32, 1),
    ]
    
    points = []
    resolution = grid_map_msg.info.resolution
    width = grid_map_msg.info.width
    position = grid_map_msg.info.pose.position

    # Assuming 'elevation' is the layer of interest; update if needed
    layer_name = "elevation"
    if layer_name not in grid_map_msg.layers:
        rospy.logerr(f"Layer '{layer_name}' not found in GridMap!")
        return None
    
    layer_index = grid_map_msg.layers.index(layer_name)
    data = grid_map_msg.data[layer_index].data

    # Convert GridMap data to PointCloud2 points
    for i, value in enumerate(data):
        if not value == value:  # Skip NaN
            continue
        x = position.x + (i % width) * resolution
        y = position.y + (i // width) * resolution
        z = value
        points.append([x, y, z])

    # Pack the points into PointCloud2 format
    pointcloud_data = []
    for p in points:
        pointcloud_data.append(struct.pack('fff', *p))
    pointcloud_data = b''.join(pointcloud_data)

    pointcloud = PointCloud2(
        header=header,
        height=1,
        width=len(points),
        fields=fields,
        is_bigendian=False,
        point_step=12,
        row_step=12 * len(points),
        data=pointcloud_data,
        is_dense=True,
    )
    return pointcloud


def gridmap_callback(grid_map_msg):
    """
    Callback function to convert GridMap to PointCloud2 and publish it.

    Args:
        grid_map_msg (GridMap): Received GridMap message.
    """
    pointcloud_msg = gridmap_to_pointcloud2(grid_map_msg)
    if pointcloud_msg:
        pointcloud_pub.publish(pointcloud_msg)


if __name__ == "__main__":
    rospy.init_node("gridmap_to_pointcloud2_converter")

    # Subscribers and Publishers
    rospy.Subscriber("/elevation_mapping/elevation_map", GridMap, gridmap_callback)
    pointcloud_pub = rospy.Publisher("/elevation_pointcloud", PointCloud2, queue_size=10)

    rospy.loginfo("GridMap to PointCloud2 converter node started.")
    rospy.spin()
